-- BimeNama v2: Supabase schema for Netlify static hosting
-- Run the entire file in Supabase > SQL Editor > New query.
-- SECURITY: Never put a service_role/secret key in index.html.

create extension if not exists pgcrypto;

create table if not exists public.insurance_products (
  id text primary key,
  title text not null check (char_length(title) between 1 and 120),
  category text not null check (char_length(category) between 1 and 60),
  icon text not null default '🛡️' check (char_length(icon) <= 20),
  description text not null check (char_length(description) between 1 and 1500),
  official_url text not null check (official_url ~ '^https://'),
  is_published boolean not null default true,
  sort_order integer not null default 100,
  updated_at timestamptz not null default now()
);

create table if not exists public.site_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- User-specific tables are prepared for the next cloud-sync phase. RLS ensures
-- each signed-in user can access only their own rows.
create table if not exists public.user_favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id text not null references public.insurance_products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);
create table if not exists public.user_policies (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  expiry_date date not null,
  note text not null default '' check (char_length(note) <= 120),
  created_at timestamptz not null default now()
);

alter table public.insurance_products enable row level security;
alter table public.site_admins enable row level security;
alter table public.user_favorites enable row level security;
alter table public.user_policies enable row level security;

-- SECURITY DEFINER avoids recursive RLS when checking the admin allow-list.
create or replace function public.is_site_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
set row_security = off
as $$
  select exists (
    select 1 from public.site_admins a where a.user_id = auth.uid()
  );
$$;
revoke all on function public.is_site_admin() from public;
grant execute on function public.is_site_admin() to anon, authenticated;

-- Remove old policy names if this script is rerun.
drop policy if exists "public can read published insurance products" on public.insurance_products;
drop policy if exists "admins can read all insurance products" on public.insurance_products;
drop policy if exists "admins can insert insurance products" on public.insurance_products;
drop policy if exists "admins can update insurance products" on public.insurance_products;
drop policy if exists "admins can delete insurance products" on public.insurance_products;
drop policy if exists "users can read own admin row" on public.site_admins;
drop policy if exists "users manage own favorites" on public.user_favorites;
drop policy if exists "users manage own policies" on public.user_policies;

create policy "public can read published insurance products"
on public.insurance_products for select to anon, authenticated
using (is_published = true or public.is_site_admin());
create policy "admins can insert insurance products"
on public.insurance_products for insert to authenticated
with check (public.is_site_admin());
create policy "admins can update insurance products"
on public.insurance_products for update to authenticated
using (public.is_site_admin()) with check (public.is_site_admin());
create policy "admins can delete insurance products"
on public.insurance_products for delete to authenticated
using (public.is_site_admin());

-- A user can see only their own admin-list row; only trusted SQL editor can grant admin.
create policy "users can read own admin row"
on public.site_admins for select to authenticated
using (user_id = auth.uid());

create policy "users manage own favorites"
on public.user_favorites for all to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "users manage own policies"
on public.user_policies for all to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());

grant select on public.insurance_products to anon, authenticated;
grant insert, update, delete on public.insurance_products to authenticated;
grant select on public.site_admins to authenticated;
grant select, insert, update, delete on public.user_favorites to authenticated;
grant select, insert, update, delete on public.user_policies to authenticated;

insert into public.insurance_products
(id,title,category,icon,description,official_url,is_published,sort_order)
values
('car-third','بیمه شخص ثالث خودرو','خودرو','🚘','برای بررسی شرایط و استعلام بیمه شخص ثالث خودرو از ارائه‌دهنده رسمی استفاده کنید.','https://www.azki.com/car-insurance',true,1),
('car-body','بیمه بدنه خودرو','خودرو','🚗','برای بررسی پوشش‌ها و استعلام قیمت بیمه بدنه، مشخصات خودرو را در صفحه رسمی وارد کنید.','https://www.azki.com/car-insurance',true,2),
('motor','بیمه موتورسیکلت','موتور','🏍️','شرایط بیمه موتور و قیمت نهایی پس از استعلام در سایت ارائه‌دهنده مشخص می‌شود.','https://www.azki.com/car-insurance',true,3),
('home','بیمه آتش‌سوزی و ساختمان','ساختمان','🏠','پوشش‌های ساختمان، آتش‌سوزی و زلزله را در صفحه رسمی بررسی کنید.','https://www.azki.com/',true,4),
('life','بیمه عمر','عمر و درمان','💚','شرایط، تعهدات و جزئیات بیمه عمر را پیش از خرید از ارائه‌دهنده بررسی کنید.','https://www.azki.com/',true,5),
('health','بیمه درمان تکمیلی','عمر و درمان','🩺','نوع پوشش و شرایط قرارداد می‌تواند متفاوت باشد؛ جزئیات را در سایت ارائه‌دهنده بررسی کنید.','https://www.azki.com/',true,6),
('travel','بیمه مسافرتی','مسافرتی','✈️','پوشش‌ها را با توجه به مقصد و مدت سفر در صفحه رسمی بررسی کنید.','https://www.azki.com/',true,7),
('liability','بیمه مسئولیت','سایر','🛡️','نوع مسئولیت و حدود تعهدات باید متناسب با فعالیت موردنظر بررسی شود.','https://www.azki.com/',true,8)
on conflict (id) do nothing;

-- After creating an account through the website, copy its UUID from
-- Supabase > Authentication > Users, then run the following in SQL Editor:
-- insert into public.site_admins (user_id) values ('PASTE-USER-UUID-HERE');
-- Never expose a service_role key. Admin permissions are granted only via this table.
